#include "SceneObject.h"


SceneObject::SceneObject(void)
{
}


SceneObject::~SceneObject(void)
{
}
