#6GEN715: Infographie  

>Code source des devoirs et/ou documents pratique.

>### Pour compiler
>1.  Ouvrir **6GEN715.sln** dans *VS2010*

>2.  Il faut s'assurer de l'emplacement des fichiers suivants: 

>  **Emplacement système 32bits de votre plateforme - system32, sysWOW64**

>		opengl32.dll  
>		glut32.dll

>	**Les fichiers suivant sont fournis avec la solution**

>		lib/glut32.lib  
>		include/glut.h

>3.	Compiler la solution ou éxécuter **Release/TP1.exe**

---

>###Utilisation
>Clique droit de la souris: ouvrir le menu

>### TP4
>Il est important de noter qu'à partir de ce laboratoire,
>l'implémentation des quaternions et maintenant d'autres
>fonctions mathématiques utile, est assurée par un projet
>libre de Will Perone, disponnible ici: 
>[https://github.com/micaelbergeron/willperone]

>Les fichiers de cette librairie sont situé exclusivement
>dans le dossier /include/willperone
