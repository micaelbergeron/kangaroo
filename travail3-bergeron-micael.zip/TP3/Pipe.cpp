#include "Pipe.h"


Pipe::Pipe(void)
{
}


Pipe::~Pipe(void)
{
}
